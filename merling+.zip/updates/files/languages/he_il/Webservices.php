<?php
$languageStrings = [ 
	'LBL_CHANGE_PASSWORD_FAILURE' => 'נכשל ניסיון לשנות את הסיסמה',
	'LBL_DATABASE_QUERY_ERROR' => 'שגיאת מסד נתונים בעת ביצוע פעולה המבוקשת',
	'LBL_INVALID_OLD_PASSWORD' => 'ערך לא חוקי שניתן לסיסמא ישנה.',
	'LBL_NEW_PASSWORD_MISMATCH' => 'סיסמא ולאשר את הסיסמה אינו תואם חדשות',
];
$jsLanguageStrings = [
];