<?php
$languageStrings = [ 
	'AJAXChat' => 'צ\'אט',
];
$jsLanguageStrings = [
];