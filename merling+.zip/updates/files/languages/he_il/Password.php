<?php
$languageStrings = [ 
	'Password' => 'הגדרת סיסמא',
	'LBL_PASSWORD_DESCRIPTION' => 'הגדר מורכבות של הסיסמה עבור משתמשים של התוכנה',
	'LBL_Password_Header' => 'פרמטרים שיקבעו את המורכבות של הסיסמה',
	'Minimum password length' => 'אורך סיסמא מינימאלי',
	'Maximum password length' => 'אורך סיסמא מרבי',
	'Uppercase letters from A to Z' => 'אותיות רישיות מ- A עד Z',
	'Lowercase letters a to z' => 'אותיות קטנות עד Z\'',
	'Password should contain numbers' => 'הסיסמא צריכה להכיל מספרים',
	'Password should contain special characters' => 'הסיסמא צריכה להכיל תווים מיוחדים',
	'LBL_ERROR' => 'שגיאה בשמירת הקובץ',
	'LBL_SAVE_OK' => 'הנתונים נשמרו',
	'characters' => 'תווים',
];
$jsLanguageStrings = [
];