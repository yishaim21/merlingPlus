<?php
$languageStrings = [ 
	'ModTracker' => 'ModTracker',
	'SINGLE_ModTracker' => 'ModTracker רשומה',
];
$jsLanguageStrings = [
];