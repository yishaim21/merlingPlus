<?php
$languageStrings = [ 
	'LBL_ADD_FEED_SOURCE' => 'הוספת מקור Feed',
	'LBL_ENTER_FEED_SOURCE' => 'הזן מקור Feed',
	'LBL_FEEDS_LIST_FROM' => 'הזנות רשימה מ',
	'LBL_FEED_SOURCE' => 'מקור הזנה',
	'LBL_RSS_FEED_SOURCES' => 'מקורות הזנת RSS',
	'LBL_SENDER' => 'שולח',
	'LBL_SET_AS_DEFAULT' => 'נקבע כברירת מחדל',
	'SINGLE_Rss' => 'עדכוני RSS',
];
$jsLanguageStrings = [
	'JS_INVALID_RSS_URL' => 'לא חוקי Rss כתובת אתר',
	'JS_RSS_MADE_AS_DEFAULT' => 'RSS Made כברירת מחדל',
	'JS_RSS_SUCCESSFULLY_SAVED' => 'RSS נשמר בהצלחה',
];