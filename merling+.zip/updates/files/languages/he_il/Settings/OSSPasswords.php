<?php
$languageStrings = [ 
	'LBL_VIEW_CONFIGUREPASS' => 'סיסמאות תצורה',
];
$jsLanguageStrings = [
];