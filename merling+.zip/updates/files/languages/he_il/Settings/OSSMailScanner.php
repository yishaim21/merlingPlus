<?php
$languageStrings = [ 
	'OSSMailScanner_manual' => 'סורק דואר',
	'OSSMailScanner' => 'סורק דואר',
	'Mail Scanner' => 'סורק דואר',
	'LBL_VIEW_LOGS' => 'יומני דואר',
];
$jsLanguageStrings = [
	'start_cron' => 'Cron התחיל',
	'end_cron_ok' => 'משימות Cron סיימו בהצלחה',
	'end_cron_error' => 'בעוד cron רץ שגיאה הופיעה',
	'JS_mail_error' => 'כתובת דואר אלקטרוני שגויה',
	'JS_time_error' => 'פורמט תאריך אינו נכון',
	'JS_StopCron' => 'ידני לעצור את cron',
	'stop_user' => 'משתמש שהפסיק סריקה',
	'Manually stopped' => 'הפסיק באופן ידני',
	'OK' => 'בסדר',
	'In progress' => 'בתהליך',
	'whether_remove_an_identity' => 'הסר את זהות?',
	'removed_identity' => 'זהות נמחקה',
];