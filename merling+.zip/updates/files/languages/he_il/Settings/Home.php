<?php
$languageStrings = [ 
	'LBL_VIEW_CREDITS' => 'קרדיטים',
	'Home' => 'קרדיטים',
];
$jsLanguageStrings = [
];