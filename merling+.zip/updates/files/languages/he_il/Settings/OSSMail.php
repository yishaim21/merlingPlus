<?php
$languageStrings = [ 
	'OSSMail' => 'תיבת דואר שלי',
];
$jsLanguageStrings = [
	'JS_ERROR_EMPTY' => 'כל שדות חייבים להסתיים',
];