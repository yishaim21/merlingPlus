<?php
$languageStrings = [ 
	'ConfReport' => 'תצורת שרת',
	'LBL_CONFIGURATION' => 'תצורת שרת',
	'LBL_CONFREPORT_DESCRIPTION' => 'מאפשר לך לוודא שהגדרות השרת הראשיות תואמות את הפרמטרים המומלצים.',
	'LBL_PARAMETER' => 'פרמטר',
	'LBL_VALUE' => 'תצורה נוכחית',
	'LBL_RECOMMENDED' => 'תצורה מומלצת',
	'LBL_FILES_PERMISSIONS' => 'קבצים / תיקיות',
	'LBL_FILE' => 'שם',
	'LBL_PATH' => 'נתיב',
	'LBL_PERMISSION' => 'רשות',
	'LBL_TRUE_PERMISSION' => 'מאושר',
	'LBL_FAILED_PERMISSION' => 'לא מורשה',
	'On' => 'ב',
	'Off' => 'כבוי',
	'NOT RECOMMENDED' => 'לא מומלץ',
	'LBL_YETIFORCE_ENGINE' => 'YetiForce מנוע',
	'LBL_CHECK_CONFIG' => 'RoundCube מנוע',
];
$jsLanguageStrings = [
];