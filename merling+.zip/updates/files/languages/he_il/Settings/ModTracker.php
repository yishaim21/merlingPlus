<?php
$languageStrings = [ 
	'ModTracker' => 'שינוי היסטוריה',
	'LBL_MODTRACKER_SETTINGS' => 'שינוי היסטוריה',
	'LBL_MODTRACKER_SETTINGS_DESCRIPTION' => 'נהל את היסטוריית שינוי במודולים',
	'LBL_MODULE' => 'מודול',
	'LBL_ACTIVE' => 'עקוב אחר שינויים',
	'LBL_TOOLS' => 'כלים',
	'LBL_TRACK_CHANGES_ENABLED' => 'שינויי מסלול אפשרו',
	'LBL_TRACK_CHANGES_DISABLE' => 'לעקוב אחר שינויי נכים',
];
$jsLanguageStrings = [
];