<?php
$languageStrings = [ 
	'Password' => 'הגדרת סיסמא',
	'LBL_PASSWORD_DESCRIPTION' => 'מורכבות סט של סיסמא עבור משתמשים של תוכנה',
	'LBL_Password_Header' => 'פרמטרים שיקבעו את מורכבות של סיסמא',
	'Minimum password length' => 'אורך סיסמא מינימאלית',
	'Maximum password length' => 'אורך סיסמא מרבית',
	'Uppercase letters from A to Z' => 'אותיות רישיות מא \'עד ת',
	'Lowercase letters a to z' => 'אותיות קטנות \'עד ת\'',
	'Password should contain numbers' => 'סיסמא צריכה להכיל מספרים',
	'Password should contain special characters' => 'סיסמא צריך להכיל תווים מיוחדים',
	'LBL_ERROR' => 'קובץ שגיאה בשמירה',
	'LBL_SAVE_OK' => 'נתונים נשמרו',
	'characters' => 'תווים',
];
$jsLanguageStrings = [
];