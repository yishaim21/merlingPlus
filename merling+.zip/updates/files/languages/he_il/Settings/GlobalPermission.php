<?php
$languageStrings = [ 
	'Access to record' => 'גישה לרשומות',
	'GlobalPermission' => 'גישה לרשומות',
	'LBL_Module_desc' => 'כאן אתה יכול להגדיר שפרופילי גישה לכל הרשומות ללא קשר לתפקידים.',
	'LBL_PROFILE_NAME' => 'שם פרופיל',
	'LBL_DESCRIPTION' => 'תיאור פרופיל',
	'LBL_VIEW_ALL_DESC' => 'אם אתה סמן אפשרות זו, כל המודולים יהיו אפשרות מסומנת של: גלישה',
	'LBL_VIEW_ALL' => 'אפשר תצוגה מקדימה של כל הרשומות.',
	'LBL_EDIT_ALL_DESC' => 'אם אתה סמן אפשרות זו, כל המודולים יהיו אפשרות מסומנת של: יצירה / עריכה.',
	'LBL_EDIT_ALL' => 'לאפשר עריכה של כל הרשומות.',
	'LBL_SAVE_OK' => 'שינוי נשמר',
];
$jsLanguageStrings = [
];