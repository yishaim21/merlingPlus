<?php
$languageStrings = [ 
	'LBL_QUICK_CREATE_MODULE' => 'יצירה מהירה',
	'LBL_SEPARATOR' => 'מפריד',
	'LBL_OTHER' => 'אחר',
	'MEN_VIRTUAL_DESK' => 'טבלה עבודה',
	'MEN_LEADS' => 'לידים',
	'MEN_SALES' => 'מכירות',
	'MEN_PROJECTS' => 'פרויקטים',
	'MEN_SUPPORT' => 'תמיכה',
	'MEN_BOOKKEEPING' => 'הנהלת חשבונות',
	'MEN_HUMAN_RESOURCES' => 'משאבי אנוש',
	'MEN_SECRETARY' => 'מזכירות',
	'MEN_DATABESES' => 'מאגרי מידע',
	'MEN_TEAMWORK' => 'עבודת צוות',
	'MEN_PRODUCTBASE' => 'מסד הנתונים של מוצר',
	'MEN_LISTS' => 'רשימות',
	'MEN_SERVICESBASE' => 'מסד נתוני שירות',
];
$jsLanguageStrings = [
];