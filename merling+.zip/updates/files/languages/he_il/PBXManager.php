<?php
$languageStrings = [ 
	'LBL_PBXMANAGER_INFORMATION' => 'פרטי שיחה',
	'LBL_CUSTOM_INFORMATION' => 'מידע מותאם אישית',
	'LBL_SERVER_CONFIGURATION' => 'תצורת ספק',
	'LBL_CALL_FROM' => 'שיחה מ',
	'LBL_CALL_TO' => 'קריאה ל',
	'LBL_HIDDEN' => '(HIDDEN)',
	'Total Duration' => 'משכתי (שניות)',
	'Bill Duration' => 'משך ביל (שניות)',
	'Recording URL' => 'הקלטה',
	'Start Time' => 'שעת התחלה',
	'Call Status' => 'מצב שיחה',
	'Customer Number' => 'מספר לקוחות',
	'Customer' => 'לקוחות',
	'User' => 'משתמש',
	'SINGLE_PBXManager' => 'רשומת שיחה',
	'Direction' => 'כיוון',
	'Gateway' => 'Gateway',
	'Customer type' => 'סוג הלקוח',
	'Source UUID' => 'מקור UUID',
	'End Time' => 'שעת סיום',
	'Record Id' => 'מספר זיהוי רשומה',
];
$jsLanguageStrings = [
];