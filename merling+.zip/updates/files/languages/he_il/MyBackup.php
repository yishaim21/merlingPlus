<?php
$languageStrings = [ 
	'LBL_SIMPLEEXTENSION_HELLO_WORLD_MSG' => 'שלום העולם!',
	'LBL_SIMPLEEXTENSION_HELLO_WORLD_DESC' => 'מחרוזת זה תורגמה מתיקיית השפות',
];
$jsLanguageStrings = [
];