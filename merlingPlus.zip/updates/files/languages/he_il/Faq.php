<?php
$languageStrings = [ 
	'Answer' => 'תשובה',
	'Comments' => 'תגובות',
	'Draft' => 'טיוטה',
	'Faq' => 'שאלות נפוצות',
	'Faq No' => 'מספר שאלות ותשובות',
	'General' => 'כללי',
	'LBL_ADD_RECORD' => 'הוסף רשומה',
	'LBL_COMMENT_INFORMATION' => 'תגובות',
	'LBL_FAQ_INFORMATION' => 'מידע שאלות ותשובות',
	'LBL_RECORDS_LIST' => 'רשימת שאלות הנפוצות',
	'LBL_SOLUTION' => 'פתרון',
	'Obsolete' => 'מיושן',
	'Published' => 'פורסם',
	'Question' => 'שאלה',
	'SINGLE_Faq' => 'שאלות נפוצות',
];
$jsLanguageStrings = [
];