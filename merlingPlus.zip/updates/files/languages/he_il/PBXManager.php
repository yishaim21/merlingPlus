<?php
$languageStrings = [ 
	'LBL_PBXMANAGER_INFORMATION' => 'פרטי שיחה',
	'LBL_CUSTOM_INFORMATION' => 'מידע מותאם אישית',
	'LBL_SERVER_CONFIGURATION' => 'תצורת ספק',
	'LBL_CALL_FROM' => 'שיחה מ',
	'LBL_CALL_TO' => 'קריאה ל',
	'LBL_HIDDEN' => '',
	'Total Duration' => 'משך (שניות)',
	'Bill Duration' => 'משך ביל (שניות)',
	'Recording URL' => 'הקלטה',
	'Start Time' => 'שעת ההתחלה',
	'Call Status' => 'מצב שיחה',
	'Customer Number' => 'מספר לקוחות',
	'Customer' => 'לקוחות',
	'User' => 'משתמש',
	'SINGLE_PBXManager' => 'רשומת שיחה',
];
$jsLanguageStrings = [
];