<?php
$languageStrings = [ 
	'HolidaysEntitlement' => 'זכאות לחופשה שנתית',
	'SINGLE_HolidaysEntitlement' => 'זכאות לחופשה שנתית',
	'LBL_HOLIDAYSENTITLEMENT_INFORMATION' => 'מידע מותאם אישית',
	'LBL_CUSTOM_INFORMATION' => 'מידע מערכת',
	'LBL_YEAR' => 'שנה',
	'LBL_DAYS' => 'מספר החגים',
	'LBL_EMPLOYEE' => 'עובדים',
	'LBL_NUMBER' => 'מספר',
];
$jsLanguageStrings = [
];