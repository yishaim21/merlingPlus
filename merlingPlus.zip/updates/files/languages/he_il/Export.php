<?php
$languageStrings = [ 
	'Export' => 'יצוא',
];
$jsLanguageStrings = [
];