<?php
$languageStrings = [ 
	'SINGLE_ProjectMilestone' => 'פרויקט מיילסטון',
	'LBL_ADD_RECORD' => 'הוסף רשומה',
	'LBL_RECORDS_LIST' => 'רשימת אבני דרך של פרויקט',
	'LBL_PROJECT_MILESTONE_INFORMATION' => 'פרויקט Milestone פרטים',
	'LBL_PROJECTS_LIST' => 'רשימת פרויקטים',
	'LBL_TASKS_LIST' => 'רשימת משימות',
	'LBL_MILESTONES_LIST' => 'רשימת אבן דרך',
	'description' => 'תיאור',
	'Related to' => 'פרויקט',
	'Project Milestone Name' => 'שם הפרויקט מיילסטון',
	'Milestone Date' => 'תאריך מיילסטון',
	'Project Milestone No' => 'פרויקט Milestone מספר',
	'LBL_PRIORITY' => 'עדיפות',
	'LBL_PROGRESS' => 'התקדמות',
	'PLL_INTERNAL' => 'פנימי',
	'PLL_EXTERNAL' => 'חיצוני',
	'PLL_SHARED' => 'משותף',
	'PLL_LOW' => 'נמוך',
	'PLL_NORMAL' => 'רגיל',
	'PLL_HIGH' => 'גבוה',
];
$jsLanguageStrings = [
];