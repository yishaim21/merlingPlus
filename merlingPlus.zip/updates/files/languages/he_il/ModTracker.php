<?php
$languageStrings = [ 
	'ModTracker' => 'ModTracker',
	'SINGLE_ModTracker' => 'ModTracker רשום',
];
$jsLanguageStrings = [
];