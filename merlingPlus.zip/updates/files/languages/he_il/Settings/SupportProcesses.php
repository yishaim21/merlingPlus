<?php
$languageStrings = [ 
	'LBL_SUPPORT_PROCESSES' => 'תהליכי תמיכה',
	'LBL_GENERAL_CONFIGURATION' => 'כללי תצורה',
	'LBL_OTHER' => 'אחר',
	'LBL_INFO' => 'מידע',
	'LBL_TYPE' => 'סוג',
	'LBL_TICKET_STATUS_INFO' => 'סטטוסי קביעת כרטיס שנסגר',
	'LBL_SAVE_CONFIG_OK' => 'שינויים נשמרו',
	'LBL_SAVE_CONFIG_ERROR' => 'שינויים נשמרו.',
	'SupportProcesses' => 'תהליכי תמיכה',
];
$jsLanguageStrings = [
];