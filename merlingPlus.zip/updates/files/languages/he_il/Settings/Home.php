<?php
$languageStrings = [ 
	'LBL_VIEW_CREDITS' => 'קרדיטים',
];
$jsLanguageStrings = [
];