<?php
$languageStrings = [ 
	'LBL_SALES_PROCESSES' => 'תהליכי מכירות',
	'LBL_SALES_PROCESSES_DESCRIPTION' => '#VALUE!',
	'LBL_LIMIT_PRODUCT_AND_SERVICE' => 'מאפשר לבחור מרשימת מוצרים רק אלה הקשורים לנבחרו oportunity. ספק ל: חישובים, הצעות מחיר, הזמנות ומכירות חשבוניות.',
	'LBL_PRODUCTS_AND_SERVICES_POPUP' => 'מוצרים ושירותי רשימת בחירה',
	'LBL_UPDATE_SHARED_PERMISSIONS' => 'עדכוני שיתוף הרשאות ממוצר / שירות בהזדמנות כאשר יחס בין הזדמנות ומוצר / שירות נוצר.',
	'LBL_CALCULATIONS' => 'חישובים',
	'LBL_STATUSES_CLOSED_CALCULATION' => 'סטטוסי קביעת חישוב שנסגר',
	'LBL_POTENTIALS' => 'הזדמנויות',
	'LBL_STATUSES_CLOSED_POTENTIAL' => 'סטטוסי קביעת הזדמנות שנסגר',
	'LBL_ASSETS' => 'מוצרים נמכרים',
	'LBL_STATUSES_CLOSED_ASSETS' => 'סטטוסי קביעה שמוצר נמכר סגור',
	'LBL_CREATE_POTENTIALS' => 'חסימת יצירת הזדמנויות לחשבונות / ארגונים שבהוקצו לאינה משתמשת',
	'SalesProcesses' => 'תהליכי מכירות',
];
$jsLanguageStrings = [
];