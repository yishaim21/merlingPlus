<?php
$languageStrings = [ 
	'LBL_VIEW_CONFIGUREPASS' => 'סיסמות תצורה',
	'OSSPasswords' => 'סיסמות תצורה',
];
$jsLanguageStrings = [
];