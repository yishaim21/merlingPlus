<?php
$languageStrings = [ 
	'LBL_CONVERSION' => 'המרתי',
	'LBL_CONVERSION_TO_ACCOUNT' => 'לשנות מוקצה ל',
	'LBL_CONVERSION_TO_ACCOUNT_INFO' => 'כאשר אפשרות זו מסומנת, משתמש שממיר ליד לחשבון הופך מוקצה ל',
	'LBL_LEADS' => 'לידים',
	'LBL_INFO' => 'מידע',
	'LBL_VALUES' => 'ערכים',
	'LBL_GROUPS_INFO' => 'קבוצות ללא מוקצה ל',
	'LBL_LEAD_STATUS' => 'סטטוסים המצביעים על סוף העבודה עם לידים',
	'LBL_CURRENTUSER_STATUS' => 'לשנות מוקצה למשתמש שעורך רשום',
	'LBL_CONVERT_LEAD_MERGE' => 'קישור פגישת רשומה דרישות שצוין בעת ​​המרה מעופרת לחשבון',
	'LBL_CONVERT_LEAD_MERGE_ALERT' => 'אפשרות זו מאפשר מערכת להצטרף באופן אוטומטי שיא המרה עם כבר מקיימת - החשבון חדש לא תיוצר # במקום לנתונים קיימים שיא יועבר מהעופרה',
	'LBL_CONDITION' => 'להוסיף מצב',
	'MarketingProcesses' => 'תהליכי שיווק',
];
$jsLanguageStrings = [
	'JS_NO_CONDITIONS' => 'מצב אחד לפחות נדרש',
];