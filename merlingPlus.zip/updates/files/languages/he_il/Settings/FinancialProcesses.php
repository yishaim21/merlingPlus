<?php
$languageStrings = [ 
	'LBL_GENERAL' => 'כללי',
];
$jsLanguageStrings = [
];