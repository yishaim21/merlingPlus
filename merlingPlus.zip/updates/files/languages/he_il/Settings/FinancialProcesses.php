<?php
$languageStrings = [ 
	'LBL_GENERAL' => 'כללי',
	'FinancialProcesses' => 'תהליכים פיננסיים',
];
$jsLanguageStrings = [
];