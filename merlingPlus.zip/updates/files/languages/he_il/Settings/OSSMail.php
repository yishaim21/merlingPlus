<?php
$languageStrings = [ 
	'OSSMail' => 'תיבת הדואר שלי',
];
$jsLanguageStrings = [
	'JS_ERROR_EMPTY' => 'כל השדות חייבים להסתיים',
];