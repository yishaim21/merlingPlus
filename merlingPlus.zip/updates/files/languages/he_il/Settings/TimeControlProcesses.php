<?php
$languageStrings = [ 
	'LBL_TIMECONTROL_PROCESSES' => 'תהליכי בקרה זמן',
	'LBL_TIMECONTROL_PROCESSES_DESCRIPTION' => '#VALUE!',
	'LBL_ONEDAY_VALID' => 'זמן עבודה מוגבל ל -24 שעות',
	'LBL_TIMEOVERLAP_VALID' => 'לאפשר זמן חופף',
	'LBL_GENERAL_SETTINGS' => 'הגדרות כלליות',
	'TimeControlProcesses' => 'תהליכי בקרה זמן',
];
$jsLanguageStrings = [
];