<?php
$languageStrings = [ 
	'Updates' => 'עדכונים',
	'LBL_YES' => 'כן',
	'LBL_NO' => 'לא',
	'LBL_TIME' => 'תאריך',
	'LBL_USER' => 'שם משתמש',
	'LBL_FROM_VERSION' => 'מגרסה',
	'LBL_TO_VERSION' => 'גרסה',
	'LBL_RESULT' => 'סטטוס',
	'LBL_UPDATES' => 'עדכונים',
	'LBL_UPDATES_DESCRIPTION' => 'היסטורית עדכונים',
	'LBL_IMPORT_UPDATE' => 'עדכון העלאה',
];
$jsLanguageStrings = [
];