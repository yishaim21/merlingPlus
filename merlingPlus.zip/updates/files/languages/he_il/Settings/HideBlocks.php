<?php
$languageStrings = [ 
	'HideBlocks' => 'הסתר בלוקים',
	'LBL_HIDEBLOCKS' => 'הסתר בלוקים',
	'LBL_HIDEBLOCKS_DESCRIPTION' => 'בחר בלוקים עם שדות להסתרה',
	'LBL_BLOCK_LABEL' => 'בלוק',
	'LBL_MODULE' => 'מודול',
	'LBL_ENABLED' => 'פעיל',
	'LBL_EDIT_BLOCK' => 'עריכה',
	'LBL_NEW_BLOCK' => 'צור',
	'LBL_BLOCK' => 'בלוק',
	'LBL_NEXT' => 'הבא',
	'LBL_VIEW' => 'צפה ב',
	'LBL_MANDATORY_FIELDS_EXIST' => 'בלוק זה לא יכול להיות מוסתר מכיוון שהוא מכיל שדות חובה.',
];
$jsLanguageStrings = [
];