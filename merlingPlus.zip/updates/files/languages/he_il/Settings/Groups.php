<?php
$languageStrings = [ 
	'LBL_ADD_RECORD' => 'הוסף רשומה',
	'LBL_ADD_USERS_ROLES' => 'הוסף משתמשים, תפקידים ...',
	'LBL_DUPLICATES_EXIST' => 'שם קבוצה כבר קיים',
	'LBL_GROUP_MEMBERS' => 'חברי קבוצה',
	'LBL_GROUP_NAME' => 'שם קבוצה',
	'LBL_ROLEANDSUBORDINATE' => 'תפקיד ופקודים',
	'LBL_TO_OTHER_GROUP' => 'לקבוצה אחרות',
	'LBL_TRANSFORM_OWNERSHIP' => 'העברת בעלות',
	'RoleAndSubordinates' => 'תפקיד ופקודים',
	'SINGLE_Groups' => 'קבוצה',
	'Groups' => 'קבוצות',
	'Users' => 'משתמשים',
	'Roles' => 'תפקידים',
	'Name' => 'שם קבוצה',
	'Description' => 'תיאור',
];
$jsLanguageStrings = [
	'JS_PLEASE_SELECT_ATLEAST_ONE_MEMBER_FOR_A_GROUP' => 'אנא בחר לפחות חבר אחד לקבוצה',
	'JS_RECORD_DELETED_SUCCESSFULLY' => 'הקבוצה נמחקה בהצלחה',
];