<?php
$languageStrings = [ 
	'OSSProjectTemplates' => 'OSSProjectTemplates',
];
$jsLanguageStrings = [
	'JS_FILL_REQUIRED_FIELDS' => 'מלא שדות חובה',
	'JS_FIELD_INCORRECT' => 'שדה עם כמות הימים הוא שגוי',
];