<?php
$languageStrings = [ 
	'ModTracker' => 'שינוי ההיסטוריה',
	'LBL_MODTRACKER_SETTINGS' => 'שינוי ההיסטוריה',
	'LBL_MODTRACKER_SETTINGS_DESCRIPTION' => 'נהל את היסטוריית שינוי במודולים',
	'LBL_MODULE' => 'מודול',
	'LBL_ACTIVE' => 'עקוב אחר שינויים',
	'LBL_TOOLS' => 'כלים',
	'LBL_TRACK_CHANGES_ENABLED' => 'שינויי מסלול אפשר',
	'LBL_TRACK_CHANGES_DISABLE' => 'לעקוב אחר שינויי נכים',
];
$jsLanguageStrings = [
];