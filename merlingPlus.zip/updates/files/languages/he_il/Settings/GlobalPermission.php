<?php
$languageStrings = [ 
	'Access to record' => 'גישה לרשומות',
	'GlobalPermission' => 'גישה לרשומות',
	'LBL_Module_desc' => 'כאן אתה יכול להגדיר שפרופילי גישה לכל רשומות ללא קשר לתפקידים.',
	'LBL_PROFILE_NAME' => 'שם פרופיל',
	'LBL_DESCRIPTION' => 'תיאור פרופיל',
	'LBL_VIEW_ALL_DESC' => 'אם אתה סמן אפשרות זו, כל המודולים תהיה אפשרות המסומנת של: גלישה',
	'LBL_VIEW_ALL' => 'אפשר תצוגה מקדימה של כל רשומות.',
	'LBL_EDIT_ALL_DESC' => 'אם אתה סמן אפשרות זו, כל המודולים יהיה אפשרות מסומנת של: יצירה / עריכה.',
	'LBL_EDIT_ALL' => 'לאפשר עריכה של כל רשומות.',
	'LBL_SAVE_OK' => 'שינוי נשמר',
];
$jsLanguageStrings = [
];