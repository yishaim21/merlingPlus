<?php
$languageStrings = [ 
	'LBL_QUICK_CREATE_MODULE' => 'יצירה מהירה',
	'LBL_SEPARATOR' => 'מפריד',
	'LBL_OTHER' => 'אחר',
	'MEN_VIRTUAL_DESK' => 'טבלת עבודה',
	'MEN_COMPANIES_CONTACTS' => 'חברות ומגעים',
	'MEN_SALES' => 'מכירות',
	'MEN_PROJECTS' => 'פרויקטים',
	'MEN_SUPPORT' => 'תמיכה',
	'MEN_BOOKKEEPING' => 'הנהלת חשבונות',
	'MEN_HUMAN_RESOURCES' => 'משאבי אנוש',
	'MEN_SECRETARY' => 'מזכיר',
	'MEN_DATABESES' => 'מאגרי מידע',
	'MEN_TEAMWORK' => 'עבודת צוות',
	'MEN_PRODUCTBASE' => 'מסד נתונים של מוצר',
	'MEN_LISTS' => 'רשימות',
	'MEN_SERVICESBASE' => 'מסד נתוני שירות',
	'Menu' => 'תפריט',
];
$jsLanguageStrings = [
];